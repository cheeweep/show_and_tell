%example.m
%shows very basic usage of the drr.m code
%
%July 2014, Michael Folkerts (mmfolkerts@gmail.com)
%Dept. of Physics, Univ. of California San Diego
%Dept. of Radiation Oncology, Div. of Medical Phyisics and Engineering, UT Southwestern Medical Center

%some settings
tube_voltage = 120; %(kVp) CT imaging beam energy 
voxel_size = [1,1,1]; %(mm)
detector_dimension = [640,480]; %(pixels)
pixel_size = .8; %(mm) we assume square pixels
isocenter = [50,50,50]; %(mm) sets origin relative to voxel data corner (1,1,1)
angles = [0,22]; %(degrees) can be a list of many angles

load muH2O_nearest.mat %shape preserving interpolated function from NIST data.
%uncomment below to display attenuation chart
%figure();
%loglog(muH2O_nearest(1:10000));


%create test phantom
voxels_hu = random('Poisson',1,100,100,100)*1000;
voxels_hu(25:75,25:50,25:75) = 2000;
voxels_hu(25:75,51:75,25:75) = 0;

%convert HU to Attenuation (1/mm) based on beam energy (not necessary for
%code to run, but is more correct when using CT data
voxel_att = HU_to_attenuation( voxels_hu, muH2O_nearest(tube_voltage) ); %(1/mm)

%create a DRR
projections = drr(voxel_att,voxel_size,detector_dimension,pixel_size,isocenter,angles);

%show result
figure()
imagesc(projections(:,:,1));
colormap('gray');

figure()
imagesc(projections(:,:,2));
colormap('gray')

%enjoy!