%{
[mu/rho] cm^2/g
mu/rho*rho = cm^-1
cm^-1 * cm/10mm = mm^-1

so [mu/rho/10] = mm^-1
%}

function [attenuationData] = HU_to_attenuation(HU_Data,muH20)
   %units of [muH20] = inverse mm (In DRRprojection, all units are mm)
   attenuationData = HU_Data*muH20/1000.0 + muH20; %HU to linear attenuation
end