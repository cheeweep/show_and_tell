%function [projection] = drr (voxel_data, voxel_size_mm, detector_dimensions, pixel_size_mm, isocenter_mm, cbct_angles_deg)
%Creates a 2D projection at each cbct_angle of voxel_data. the projection
%axis is defined by the isocenter to which the source and center of
%the detector are aligned. This simulation assumes standard Cone Beam CT
%geometry (source to isocenter distance is 100 cm and source to detector
%distance is 150cm).
%
%voxel_data: must be a 3 dimensional matrix (typically of CT data)
%voxel_size_mm: a 3 element vector listing the size (in mm) of the voxels
%               along each dimension
%detector_dimension: a 2 element vector listing the dimensions (number of
%                    pixels) in each dimension (u,v)
%pixel_size_mm: a number defining the height and width of each pixel
%               (assumes square pixel)
%isocenter_mm: a 3 element vector pointing from the origin (corner) of the
%              matrix element(1,1,1) to the isocenter
%cbct_angles_deg: a list of angles to generate projections
%
%Retrun Variable
%projection: a 3D matrix with the 3rd dimension representing the angle of
%roatation
%
%{
 Author: Michael M. Folkerts mmfolkerts@gmail.com
 Institution: UCSD Physics, UTSW Radiation Oncology
 Updated: 2014-July.
 Notes: Siddon's Incremental algorithm | modified to read in 3D matlab matrix | Simplified Input | No guarantees!!

 References: 
 R.L. Siddon,
 "Fast calculation of the exact radiological path for a three-dimensional CT
 array," Medical Physics 12, 252-255 (1985).

 F. Jacobs, E. Sundermann, B. De Sutter, M. Christiaens and I. Lemahieu,
 "A fast algorithm to calculate the exact radiological path through a pixel_size_mmel or voxel space,"
 Journal of Computing and Information Technology 6, 89-94 (1998).
 
 G. Han, Z. Liang and J. You,
 "A fast ray tracing technique for TCT and ECT studies,"
 IEEE Medical Imaging Conference 1999.
%}

function [projection] = drr (voxel_data, voxel_size_mm, detector_dimensions, pixel_size_mm, isocenter_mm, cbct_angles_deg)
    %room coordinates in mm.
    
    tic;
    
    %initialize memory for speed:
    projection = zeros(detector_dimensions(2),detector_dimensions(1),size(cbct_angles_deg,2));
    
    %constants:
    PLANE_TOL = realmin;%.0001;
    STRIDE_TOL = realmin;%.0001;
    RAY_TOL = realmin;
    EPSILON = 10e-5;
    SAD = 1000; %source to axis distance
    SID = 1500; %sounce to imager(detector) distance
    
    %this will verify the size:
    if ndims(voxel_data)~=3
        error('voxel_data must be 3-dimensional')
    elseif ndims(voxel_size_mm) ~=2 | length(voxel_size_mm) ~= 3
        error('voxel_size_mm must be a 3 element vector')
    elseif ndims(detector_dimensions) ~=2 | length(detector_dimensions) ~= 2
        error('detector_dimensions must be a 2 element vector')
    elseif isscalar(pixel_size_mm) ~=1
        error('pixel_size_mm must be a scalar')
    elseif ndims(isocenter_mm) ~=2 | length(isocenter_mm) ~= 3
        error('voxel_size_mm must be a 3 element vector')
    elseif ndims(cbct_angles_deg) ~= 2
        error('cbct_angles_deg must be a list')
    
    end
        
    voxDim = [size(voxel_data,1), size(voxel_data,2), size(voxel_data,3)];
        
    Dx = double(voxDim(1));
    Dy = double(voxDim(2));
    N = Dx*Dy*double(voxDim(3));
    
    %uncomment to generate P-matrix:
    %matrix = single(zeros(detector_dimensions(2)*detector_dimensions(1)*sum(voxDim),2));
    
    
    %difine voxel boundaries:
    voxPlanes.min = -isocenter_mm
    voxPlanes.max = voxPlanes.min + double(voxel_size_mm).*double(voxDim)
    
    %define up:
    up = [0,0,1]; %points up, length of pixel_size_mmel
    
    %end initialization timer:
    init_time = toc;
    
    %start tracing timer:
    tic;
    
    
    %for each angle:
    theta = pi/180*cbct_angles_deg; %convert to radians
    for th = 1:size(theta,2) 
        fprintf('Angle:%f\n',cbct_angles_deg(th));
        projectionAxis = [cos(theta(th)),sin(theta(th)),0]; %vector pointing at source
        source = SAD*projectionAxis; %vector from origin to source
        detector = -(SID-SAD)*projectionAxis; %vector from origin to CENTER of detector
        
        %define pixel_size_mmel vectors:
        pixel_size_mmel.up = pixel_size_mm*up; %points up, length of pixel_size_mmel
        pixel_size_mmel.left = pixel_size_mm*cross(projectionAxis,up); %vector pointing left, parallel to detector
        
        %define upper lefthand corner of detector:
        corner = detector + ( detector_dimensions(1)*pixel_size_mmel.left + detector_dimensions(2)*pixel_size_mmel.up )/2;
        
        %define incremental vectors:
        pixel_size_mmel.right = -pixel_size_mmel.left;
        pixel_size_mmel.down = -pixel_size_mmel.up;
        
        %uncomment to generate P-matrix:
        %mtxCount = 1;
        %rayCount = 1;
        
        fprintf('Tracing Rows:\n')
        for row = 1:detector_dimensions(2)
           if(mod(row,50)==0),fprintf('row:\t%i...\n',row);end
           for col = 1:detector_dimensions(1)
                %if(mod(col,2)==0),fprintf('.');end

                pixel_size_mmPt = corner + (row-1)*pixel_size_mmel.down + (col-1)*pixel_size_mmel.right; %ray end point
                ray = pixel_size_mmPt - source; %ray to be traced
                
                % find parametrized (t) voxel plane (min or max) intersections:
                % PLANE = P1 + t(P2-P1)
                tm(1,:) = ( voxPlanes.min - source ) ./ (ray + RAY_TOL);
                tm(2,:) = ( voxPlanes.max - source ) ./ (ray + RAY_TOL);

                % compute (parametric) intersection values
                direction = (pixel_size_mmPt < source)*(-2) + 1;
                tmax = [ max([tm(1, 1), tm(2, 1)]), max([tm(1, 2), tm(2, 2)]), max([tm(1, 3), tm(2, 3)]), 1.0 ];
                tmin = [ min([tm(1, 1), tm(2, 1)]), min([tm(1, 2), tm(2, 2)]), min([tm(1, 3), tm(2, 3)]), 0.0 ];

                [ti,ti_idx] = max(tmin);
                [tf,tf_idx] = min(tmax);
                
                if(ti < tf) % if ray intersects volume
                
	                start = ray*ti + source;
	
                    %find index for each dimension:
                    tidx = floor( (start-voxPlanes.min+PLANE_TOL)./voxel_size_mm );
                    
                    %(parametric) intersection values...
                    dir01 = (direction + 1)./2; %makes 0 or 1
                    tnext = (voxPlanes.min + ( (tidx + dir01).*voxel_size_mm - source ) )./ (ray+RAY_TOL); % parametric value for next plane intersection
                    tstep = abs(voxel_size_mm./ray); % parametric step size
                    
                    %address special cases...
                    if(ti == tm(2,ti_idx)) %if intersection is a "max" plane
                    	tidx(ti_idx) = voxDim(ti_idx)-1;
                    	tnext(ti_idx) = ti + tstep(ti_idx); %next plane crossing 
                    else
                    	tidx(ti_idx) = 0;
                    	tnext(ti_idx) = ti + tstep(ti_idx); %next plane crossing
                    end
                    
                    
                    % voxel index values(add one for matlab):
                    ix = tidx(1)+1;
                    iy = tidx(2)+1;
                    iz = tidx(3)+1;
                    
                    tx = tnext(1);
                    ty = tnext(2);
                    tz = tnext(3);
                    
                    sx = tstep(1);
                    sy = tstep(2);
                    sz = tstep(3);
                    
                    temp = ti;
                    pixel_size_mmIntensity = 0;
                    
                    %uncomment to generate P-matrix:
                    %pixel_size_mmNum = 1;
               
                    len = sqrt(ray*ray'); % ray length
     
                    while temp+EPSILON < tf 
                        if( tx<ty && tx<tz)

                            try
                                pixel_size_mmIntensity = pixel_size_mmIntensity + (tx - temp)*double(voxel_data(ix,iy,iz));
							catch
								fprintf('\tNote: Over/Under shooting index @ column %i, (%i,%i,%i)\n',col,ix,iy,iz);
								tf=-Inf; %to break
							end 
							
                            %uncomment to generate P-matrix:
                            %matrix(mtxCount,:)= [(tx - temp)*len,N*(rayCount-1) + Dx*Dy*(iz-1) + Dx*(iy-1) + ix-1];
                            %mtxCount = mtxCount + 1;
                            
                            temp = tx;
                            tx = tx + sx;
                            ix = ix + direction(1);
                            
                        else if( ty<tz)
                                try
	                                pixel_size_mmIntensity = pixel_size_mmIntensity + (ty - temp)*double(voxel_data(ix,iy,iz));
    							catch
    								fprintf('\tNote: Over/Under shooting index @ column %i, (%i,%i,%i)\n',col,ix,iy,iz);
    								tf=-Inf; %to break loop
    							end  
    							                          
                                %uncomment to generate P-matrix:
                                %matrix(mtxCount,:)= [(ty - temp)*len,N*(rayCount-1) + Dx*Dy*(iz-1) + Dx*(iy-1) + ix-1];
                                %mtxCount = mtxCount + 1;
                                
                                temp = ty;
                                ty = ty + sy;
                                iy = iy + direction(2);
                            else
                                try
	                                pixel_size_mmIntensity = pixel_size_mmIntensity + (tz - temp)*double(voxel_data(ix,iy,iz));
    							catch
    								fprintf('\tNote: Over/Under shooting index @ column %i, voxel_data(%i,%i,%i)\n',col,ix,iy,iz);
    								tf=-Inf; %to break loop
    							end 
                                
                                %uncomment to generate P-matrix:
                                %matrix(mtxCount,:)= [(tz - temp)*len,N*(rayCount-1) + Dx*Dy*(iz-1) + Dx*(iy-1) + ix-1];
                                %mtxCount = mtxCount + 1;
                                
                                temp = tz;
                                tz = tz + sz;
                                iz = iz + direction(3);
                                 
                            end
                        end
                        
                    end %end while
   
                    projection(row,col,th) = pixel_size_mmIntensity * len;
                
                else %if no intersections
                    projection(row,col,th) = 0;
                end %if intersections
                
                %uncomment to generate P-matrix:
                %rayCount = rayCount + 1;
                
           end %cols
           %fprintf('\n');
        end %rows
        
        %uncomment to generate P-matrix:
        %matrix = matrix(1:mtxCount-1,:);
        
    end %cbct_angles_deg
    
    %stop trace timer:
    trace_time = toc
    fprintf('\n')
end %function
%}